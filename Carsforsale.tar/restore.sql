--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pessoacarro2;
--
-- Name: pessoacarro2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE pessoacarro2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE pessoacarro2 OWNER TO postgres;

\connect pessoacarro2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: carro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carro (
    car_cd_id integer NOT NULL,
    car_tx_brand character varying(50) NOT NULL,
    car_tx_model character varying(50) NOT NULL,
    car_tx_color character varying(50) NOT NULL,
    car_tx_fuel_type character varying(50) NOT NULL,
    car_dt_release date NOT NULL,
    car_nm_price numeric(10,2) NOT NULL,
    car_tx_plate character(7) NOT NULL,
    fk_prs_cd_id integer
);


ALTER TABLE public.carro OWNER TO postgres;

--
-- Name: carro_car_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carro_car_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carro_car_cd_id_seq OWNER TO postgres;

--
-- Name: carro_car_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carro_car_cd_id_seq OWNED BY public.carro.car_cd_id;


--
-- Name: cidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cidade (
    cid_cd_id integer NOT NULL,
    cid_tx_nome character varying(50),
    fk_est_cd_id integer
);


ALTER TABLE public.cidade OWNER TO postgres;

--
-- Name: cidade_cid_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cidade_cid_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cidade_cid_cd_id_seq OWNER TO postgres;

--
-- Name: cidade_cid_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cidade_cid_cd_id_seq OWNED BY public.cidade.cid_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_rua character varying(50),
    end_tx_bairro character varying(50),
    end_char_cep character varying(8),
    end_int_numero integer,
    fk_cid_cd_id integer
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado (
    est_cd_id integer NOT NULL,
    est_tx_estado character varying(50),
    est_tx_sigla character varying(50),
    est_char_pais character varying(8)
);


ALTER TABLE public.estado OWNER TO postgres;

--
-- Name: estado_est_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_est_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_est_cd_id_seq OWNER TO postgres;

--
-- Name: estado_est_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_est_cd_id_seq OWNED BY public.estado.est_cd_id;


--
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa (
    prs_cd_id integer NOT NULL,
    prs_tx_email character varying(50),
    prs_tx_senha character varying(20),
    prs_tx_name character varying(50) NOT NULL,
    prs_tx_cpf character(14) NOT NULL,
    prs_dt_date_born date NOT NULL,
    prs_int_tel integer NOT NULL,
    fk_end_cd_id integer
);


ALTER TABLE public.pessoa OWNER TO postgres;

--
-- Name: pessoa_prs_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pessoa_prs_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pessoa_prs_cd_id_seq OWNER TO postgres;

--
-- Name: pessoa_prs_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pessoa_prs_cd_id_seq OWNED BY public.pessoa.prs_cd_id;


--
-- Name: carro car_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carro ALTER COLUMN car_cd_id SET DEFAULT nextval('public.carro_car_cd_id_seq'::regclass);


--
-- Name: cidade cid_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade ALTER COLUMN cid_cd_id SET DEFAULT nextval('public.cidade_cid_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_cd_id_seq'::regclass);


--
-- Name: estado est_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado ALTER COLUMN est_cd_id SET DEFAULT nextval('public.estado_est_cd_id_seq'::regclass);


--
-- Name: pessoa prs_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa ALTER COLUMN prs_cd_id SET DEFAULT nextval('public.pessoa_prs_cd_id_seq'::regclass);


--
-- Data for Name: carro; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3366.dat

--
-- Data for Name: cidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3360.dat

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3362.dat

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3358.dat

--
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3364.dat

--
-- Name: carro_car_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carro_car_cd_id_seq', 25, true);


--
-- Name: cidade_cid_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cidade_cid_cd_id_seq', 5, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_seq', 5, true);


--
-- Name: estado_est_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_est_cd_id_seq', 5, true);


--
-- Name: pessoa_prs_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pessoa_prs_cd_id_seq', 5, true);


--
-- Name: carro carro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carro
    ADD CONSTRAINT carro_pkey PRIMARY KEY (car_cd_id);


--
-- Name: cidade cidade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade
    ADD CONSTRAINT cidade_pkey PRIMARY KEY (cid_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: estado estado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_pkey PRIMARY KEY (est_cd_id);


--
-- Name: pessoa pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (prs_cd_id);


--
-- Name: brand; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX brand ON public.carro USING btree (car_tx_brand);


--
-- Name: cor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cor ON public.carro USING btree (car_tx_color);


--
-- Name: fueltype; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fueltype ON public.carro USING btree (car_tx_fuel_type);


--
-- Name: carro carro_fk_prs_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carro
    ADD CONSTRAINT carro_fk_prs_cd_id_fkey FOREIGN KEY (fk_prs_cd_id) REFERENCES public.pessoa(prs_cd_id);


--
-- Name: cidade cidade_fk_est_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidade
    ADD CONSTRAINT cidade_fk_est_cd_id_fkey FOREIGN KEY (fk_est_cd_id) REFERENCES public.estado(est_cd_id);


--
-- Name: endereco endereco_fk_cid_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_fk_cid_cd_id_fkey FOREIGN KEY (fk_cid_cd_id) REFERENCES public.cidade(cid_cd_id);


--
-- Name: pessoa pessoa_fk_end_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_fk_end_cd_id_fkey FOREIGN KEY (fk_end_cd_id) REFERENCES public.endereco(end_cd_id);


--
-- PostgreSQL database dump complete
--

